(() => {
  const html = document.documentElement;
  const themeBtn = document.getElementById('theme-toggle');
  const themeLabel = document.getElementById('theme-label');

  themeBtn?.addEventListener('click', () => {
    const isDark = html.getAttribute('data-theme') !== 'light';
    html.setAttribute('data-theme', isDark ? 'light' : 'dark');
    if (themeLabel) themeLabel.textContent = isDark ? 'Light' : 'Dark';
  });

  // Mobile Menu Drawer
  const menuToggle = document.getElementById('menu-toggle');
  const mobileDrawer = document.getElementById('mobile-drawer');
  menuToggle?.addEventListener('click', () => {
    const open = mobileDrawer.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(open));
    mobileDrawer.setAttribute('aria-hidden', String(!open));
  });

  document.querySelectorAll('.mobile-nav-item').forEach(link => {
    link.addEventListener('click', () => {
      mobileDrawer?.classList.remove('open');
      menuToggle?.setAttribute('aria-expanded', 'false');
    });
  });

  // Taycan GT Interactive Perspective & Touch Swipe Scrubbing
  const viewTabs = document.querySelectorAll('.view-tab');
  const imgExterior = document.getElementById('img-exterior');
  const imgCockpit = document.getElementById('img-cockpit');
  const viewport = document.getElementById('stage-viewport');

  function setView(view) {
    viewTabs.forEach(t => {
      const active = t.dataset.view === view;
      t.classList.toggle('active', active);
      t.setAttribute('aria-selected', String(active));
    });
    imgExterior?.classList.toggle('active', view === 'exterior');
    imgCockpit?.classList.toggle('active', view === 'cockpit');
  }

  viewTabs.forEach(tab => tab.addEventListener('click', () => setView(tab.dataset.view)));

  let startX = 0;
  viewport?.addEventListener('touchstart', e => { startX = e.touches[0].clientX; }, { passive: true });
  viewport?.addEventListener('touchend', e => {
    const dx = e.changedTouches[0].clientX - startX;
    if (Math.abs(dx) > 42) {
      const current = imgExterior?.classList.contains('active') ? 'exterior' : 'cockpit';
      setView(current === 'exterior' ? 'cockpit' : 'exterior');
    }
  }, { passive: true });

  // Finish / Trim Swatches
  const trimReadout = document.getElementById('trim-readout');
  document.querySelectorAll('.swatch').forEach(swatch => {
    swatch.addEventListener('click', () => {
      document.querySelectorAll('.swatch').forEach(s => s.classList.remove('active'));
      swatch.classList.add('active');
      const accent = swatch.dataset.accent;
      const trim = swatch.dataset.trim;
      if (accent) document.documentElement.style.setProperty('--accent', accent);
      if (trimReadout && trim) trimReadout.textContent = `FINISH: ${trim.toUpperCase()}`;
    });
  });

  // Portfolio Filter Chips
  const chips = document.querySelectorAll('.chip');
  const cards = document.querySelectorAll('.work-card');
  chips.forEach(chip => {
    chip.addEventListener('click', () => {
      chips.forEach(c => c.classList.remove('active'));
      chip.classList.add('active');
      const filter = chip.dataset.filter;
      cards.forEach(card => {
        const show = filter === 'all' || card.dataset.category === filter;
        card.classList.toggle('hidden', !show);
      });
    });
  });

  // Services Accordion
  document.querySelectorAll('.accordion-trigger').forEach(trigger => {
    trigger.addEventListener('click', () => {
      const item = trigger.closest('.accordion-item');
      const isOpen = item.classList.toggle('open');
      trigger.setAttribute('aria-expanded', String(isOpen));
    });
  });

  // Inquiry Modal
  const modal = document.getElementById('inquiry-modal');
  const closeModal = document.getElementById('close-modal');
  const inquiryForm = document.getElementById('inquiry-form');
  const inquiryFeedback = document.getElementById('inquiry-feedback');

  [document.getElementById('open-inquiry'), document.getElementById('footer-inquiry')].forEach(btn => {
    btn?.addEventListener('click', () => { modal.hidden = false; });
  });

  closeModal?.addEventListener('click', () => { modal.hidden = true; });
  modal?.addEventListener('click', e => { if (e.target === modal) modal.hidden = true; });

  inquiryForm?.addEventListener('submit', e => {
    e.preventDefault();
    const name = document.getElementById('inq-name')?.value?.trim();
    if (inquiryFeedback) {
      inquiryFeedback.textContent = `Brief received for ${name || 'your team'}. Studio response scheduled within 24h.`;
    }
    inquiryForm.reset();
  });

  // Newsletter Form
  const nlForm = document.getElementById('newsletter-form');
  const nlFeedback = document.getElementById('newsletter-feedback');
  nlForm?.addEventListener('submit', e => {
    e.preventDefault();
    if (nlFeedback) nlFeedback.textContent = 'Subscribed to Forma® dispatches.';
    nlForm.reset();
  });
})();
