package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.Swipe
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.CaseStudy
import com.example.model.DriveMode
import com.example.model.StudioDestination
import com.example.ui.StudioUiState
import com.example.ui.components.ClayEditorialFooter
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.SyneFontFamily
import kotlin.math.roundToInt

@Composable
fun ShowcaseScreen(
    uiState: StudioUiState,
    onSelectPerspective: (Int) -> Unit,
    onTogglePerspective: () -> Unit,
    onSelectTrim: (Int) -> Unit,
    onSelectDriveMode: (DriveMode) -> Unit,
    onOpenCaseStudy: (CaseStudy) -> Unit,
    onOpenWebPreview: () -> Unit,
    onNavigate: (StudioDestination) -> Unit,
    onStartProject: () -> Unit,
    onNewsletterEmailChange: (String) -> Unit,
    onNewsletterSubmit: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(top = 8.dp)
    ) {
        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Column(modifier = Modifier.widthIn(max = 1180.dp)) {
                    HeroEditorialSection(
                        onOpenTaycan = {
                            uiState.allCaseStudies.firstOrNull()?.let(onOpenCaseStudy)
                        },
                        onOpenWebPreview = onOpenWebPreview
                    )
                    Spacer(modifier = Modifier.height(24.dp))
                }
            }
        }

        item {
            KineticMarqueeStrip()
            Spacer(modifier = Modifier.height(32.dp))
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Column(modifier = Modifier.widthIn(max = 1180.dp)) {
                    TaycanInteractiveStage(
                        uiState = uiState,
                        onSelectPerspective = onSelectPerspective,
                        onTogglePerspective = onTogglePerspective,
                        onSelectTrim = onSelectTrim,
                        onSelectDriveMode = onSelectDriveMode,
                        onExploreFullCase = {
                            uiState.allCaseStudies.firstOrNull()?.let(onOpenCaseStudy)
                        }
                    )
                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }

        item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Column(modifier = Modifier.widthIn(max = 1180.dp)) {
                    FeaturedWorkRail(
                        caseStudies = uiState.allCaseStudies,
                        onOpenCaseStudy = onOpenCaseStudy,
                        onViewAllWork = { onNavigate(StudioDestination.WORK) }
                    )
                    Spacer(modifier = Modifier.height(40.dp))
                }
            }
        }

        item {
            ClayEditorialFooter(
                newsletterEmail = uiState.newsletterEmail,
                newsletterSubscribed = uiState.newsletterSubscribed,
                onNewsletterEmailChange = onNewsletterEmailChange,
                onNewsletterSubmit = onNewsletterSubmit,
                onNavigate = onNavigate,
                onStartProject = onStartProject
            )
        }
    }
}

@Composable
private fun HeroEditorialSection(
    onOpenTaycan: () -> Unit,
    onOpenWebPreview: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(999.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(7.dp)
                            .clip(CircleShape)
                            .background(SignalEmerald)
                    )
                    Text(
                        text = "EDITION 2026 · APP + WEB",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Text(
                text = "00 / MANIFESTO",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.primary
            )
        }

        Text(
            text = "PRECISION\nDIGITAL\nMOTION.",
            style = MaterialTheme.typography.displayLarge.copy(fontFamily = SyneFontFamily)
        )

        Text(
            text = "Forma® crafts minimalist automotive HMIs, tactile industrial product flagships, and responsive SEO/AEO web architectures with fluid spring choreography.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.widthIn(max = 620.dp)
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Button(
                onClick = onOpenTaycan,
                shape = RoundedCornerShape(999.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.onBackground,
                    contentColor = MaterialTheme.colorScheme.background
                ),
                modifier = Modifier
                    .height(48.dp)
                    .testTag("hero_explore_case_button")
            ) {
                Text("Taycan Case Study", style = MaterialTheme.typography.labelLarge)
                Spacer(modifier = Modifier.width(6.dp))
                Icon(
                    imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                    contentDescription = null,
                    modifier = Modifier.size(16.dp)
                )
            }

            OutlinedButton(
                onClick = onOpenWebPreview,
                shape = RoundedCornerShape(999.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .height(48.dp)
                    .testTag("hero_web_preview_button")
            ) {
                Text(
                    text = "Live Website + SEO",
                    style = MaterialTheme.typography.labelLarge,
                    color = MaterialTheme.colorScheme.onBackground
                )
            }
        }
    }
}

@Composable
private fun KineticMarqueeStrip() {
    val infiniteTransition = rememberInfiniteTransition(label = "marquee")
    val offsetFraction by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 16000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "marqueeProgress"
    )
    val items = listOf(
        "AUTOMOTIVE HMI",
        "TAYCAN GT SYSTEM",
        "INDUSTRIAL DESIGN",
        "SEO & AEO SCHEMA",
        "MOBILE-FIRST MOTION",
        "CLAY HEADER & FOOTER"
    )

    Column {
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp)
                .graphicsLayer {
                    translationX = -offsetFraction * 320f
                },
            horizontalArrangement = Arrangement.spacedBy(24.dp)
        ) {
            (items + items).forEach { label ->
                Text(
                    text = "$label  •",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1
                )
            }
        }
        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
    }
}

@Composable
private fun TaycanInteractiveStage(
    uiState: StudioUiState,
    onSelectPerspective: (Int) -> Unit,
    onTogglePerspective: () -> Unit,
    onSelectTrim: (Int) -> Unit,
    onSelectDriveMode: (DriveMode) -> Unit,
    onExploreFullCase: () -> Unit
) {
    val activeTrim = uiState.activeTrim
    val glowColor by animateColorAsState(
        targetValue = activeTrim.accentColor,
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "trimGlow"
    )

    var dragDelta by remember { mutableFloatStateOf(0f) }
    val animatedParallax by animateFloatAsState(
        targetValue = dragDelta.coerceIn(-48f, 48f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "stageParallax"
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text(
            text = "01 / FLAGSHIP INTERACTIVE SHOWCASE",
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.primary
        )
        Text(
            text = "Taycan GT — Electric Motion System",
            style = MaterialTheme.typography.displayMedium
        )

        Surface(
            shape = RoundedCornerShape(24.dp),
            color = MaterialTheme.colorScheme.surface,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            modifier = Modifier
                .fillMaxWidth()
                .drawBehind {
                    drawCircle(
                        brush = Brush.radialGradient(
                            colors = listOf(glowColor.copy(alpha = 0.22f), Color.Transparent),
                            center = Offset(size.width * 0.5f, size.height * 0.22f),
                            radius = size.width * 0.65f
                        )
                    )
                }
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // Perspective Switcher & Material Readout
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant
                    ) {
                        Row(modifier = Modifier.padding(4.dp)) {
                            listOf("01 Exterior", "02 Cockpit").forEachIndexed { idx, label ->
                                val selected = uiState.selectedPerspectiveIndex == idx
                                Surface(
                                    shape = RoundedCornerShape(999.dp),
                                    color = if (selected) MaterialTheme.colorScheme.onBackground else Color.Transparent,
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(999.dp))
                                        .clickable { onSelectPerspective(idx) }
                                        .testTag("stage_perspective_$idx")
                                ) {
                                    Text(
                                        text = label,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = if (selected) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                                    )
                                }
                            }
                        }
                    }

                    Text(
                        text = activeTrim.materialCode,
                        style = MaterialTheme.typography.labelSmall,
                        color = glowColor
                    )
                }

                // Touch-Swipe Gesture Stage
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(16f / 10f)
                        .clip(RoundedCornerShape(18.dp))
                        .background(Color(0xFF070709))
                        .pointerInput(Unit) {
                            detectHorizontalDragGestures(
                                onHorizontalDrag = { _, dragAmount ->
                                    dragDelta += dragAmount * 0.45f
                                },
                                onDragEnd = {
                                    if (kotlin.math.abs(dragDelta) > 28f) {
                                        onTogglePerspective()
                                    }
                                    dragDelta = 0f
                                },
                                onDragCancel = { dragDelta = 0f }
                            )
                        }
                        .testTag("taycan_gesture_stage")
                ) {
                    AnimatedContent(
                        targetState = uiState.selectedPerspectiveIndex,
                        transitionSpec = {
                            fadeIn(spring(stiffness = Spring.StiffnessMediumLow)) togetherWith
                                fadeOut(spring(stiffness = Spring.StiffnessMediumLow))
                        },
                        label = "taycanImage"
                    ) { idx ->
                        val imageRes = if (idx == 0) R.drawable.img_taycan_hero else R.drawable.img_taycan_cockpit
                        val desc = if (idx == 0) {
                            "Taycan GT electric sports coupe exterior aerodynamic studio shot"
                        } else {
                            "Taycan GT curved glass digital cockpit instrument cluster"
                        }
                        Image(
                            painter = painterResource(id = imageRes),
                            contentDescription = desc,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .offset { IntOffset(animatedParallax.roundToInt(), 0) }
                        )
                    }

                    // Bottom Rim Tint & Gesture Hint
                    Box(
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(12.dp)
                            .clip(RoundedCornerShape(999.dp))
                            .background(Color(0xB80B0B0D))
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(5.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Rounded.Swipe,
                                contentDescription = "Swipe to switch perspective",
                                tint = Color(0xFFF6F5F1),
                                modifier = Modifier.size(14.dp)
                            )
                            Text(
                                text = "Swipe to scrub angle",
                                style = MaterialTheme.typography.labelSmall,
                                color = Color(0xFFF6F5F1)
                            )
                        }
                    }
                }

                // Finish Swatches + Drive Mode Selector
                BoxWithConstraints(modifier = Modifier.fillMaxWidth()) {
                    val isWide = maxWidth >= 600.dp
                    if (isWide) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            TrimSwatchSelector(
                                uiState = uiState,
                                onSelectTrim = onSelectTrim
                            )
                            DriveModeSelector(
                                selected = uiState.selectedDriveMode,
                                onSelect = onSelectDriveMode
                            )
                        }
                    } else {
                        Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
                            TrimSwatchSelector(
                                uiState = uiState,
                                onSelectTrim = onSelectTrim
                            )
                            DriveModeSelector(
                                selected = uiState.selectedDriveMode,
                                onSelect = onSelectDriveMode
                            )
                        }
                    }
                }

                // Live Telemetry Grid
                val mode = uiState.selectedDriveMode
                val metrics = listOf(
                    "0–100 KM/H" to mode.accel,
                    "OUTPUT" to mode.power,
                    "AERO DRAG" to mode.drag,
                    "HMI ENGINE" to mode.refresh
                )
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    metrics.forEach { (label, valText) ->
                        Surface(
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(14.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                AnimatedContent(targetState = valText, label = "metric_$label") { text ->
                                    Text(
                                        text = text,
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold
                                        ),
                                        maxLines = 1
                                    )
                                }
                            }
                        }
                    }
                }

                OutlinedButton(
                    onClick = onExploreFullCase,
                    shape = RoundedCornerShape(999.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("stage_full_case_button")
                ) {
                    Text("Inspect Full Engineering Breakdown", color = MaterialTheme.colorScheme.onSurface)
                    Spacer(modifier = Modifier.width(6.dp))
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onSurface,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TrimSwatchSelector(
    uiState: StudioUiState,
    onSelectTrim: (Int) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "FINISH // ${uiState.activeTrim.name.uppercase()}",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            uiState.trims.forEachIndexed { idx, trim ->
                val selected = idx == uiState.selectedTrimIndex
                val scale by animateFloatAsState(
                    targetValue = if (selected) 1.14f else 1f,
                    animationSpec = spring(stiffness = Spring.StiffnessMedium),
                    label = "swatchScale"
                )
                Box(
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .size(40.dp)
                        .graphicsLayer {
                            scaleX = scale
                            scaleY = scale
                        }
                        .clip(CircleShape)
                        .background(trim.swatchColor)
                        .border(
                            width = if (selected) 2.5.dp else 1.dp,
                            color = if (selected) MaterialTheme.colorScheme.onBackground else MaterialTheme.colorScheme.outline,
                            shape = CircleShape
                        )
                        .clickable { onSelectTrim(idx) }
                        .testTag("trim_swatch_$idx")
                )
            }
        }
    }
}

@Composable
private fun DriveModeSelector(
    selected: DriveMode,
    onSelect: (DriveMode) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text(
            text = "POWERTRAIN & HMI PROFILE",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Surface(
            shape = RoundedCornerShape(999.dp),
            color = MaterialTheme.colorScheme.surfaceVariant
        ) {
            Row(modifier = Modifier.padding(4.dp)) {
                DriveMode.entries.forEach { mode ->
                    val active = mode == selected
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = if (active) MaterialTheme.colorScheme.primary else Color.Transparent,
                        modifier = Modifier
                            .clip(RoundedCornerShape(999.dp))
                            .clickable { onSelect(mode) }
                            .testTag("drive_mode_${mode.name.lowercase()}")
                    ) {
                        Text(
                            text = mode.label,
                            style = MaterialTheme.typography.labelMedium,
                            color = if (active) Color.White else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun FeaturedWorkRail(
    caseStudies: List<CaseStudy>,
    onOpenCaseStudy: (CaseStudy) -> Unit,
    onViewAllWork: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(
                    text = "02 / SELECTED WORK",
                    style = MaterialTheme.typography.labelMedium,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "Recent Flagships",
                    style = MaterialTheme.typography.headlineMedium
                )
            }
            OutlinedButton(
                onClick = onViewAllWork,
                shape = RoundedCornerShape(999.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier
                    .height(44.dp)
                    .testTag("showcase_view_all_work")
            ) {
                Text("All Work", color = MaterialTheme.colorScheme.onSurface)
            }
        }

        LazyRow(
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            items(caseStudies, key = { it.id }) { item ->
                Surface(
                    shape = RoundedCornerShape(22.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier
                        .width(292.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .clickable { onOpenCaseStudy(item) }
                        .testTag("featured_card_${item.id}")
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .aspectRatio(4f / 3f)
                        ) {
                            Image(
                                painter = painterResource(id = item.primaryImageRes),
                                contentDescription = item.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize()
                            )
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = Color(0xCC0B0B0D),
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(12.dp)
                            ) {
                                Text(
                                    text = item.indexNumber,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = Color(0xFFF6F5F1),
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                                )
                            }
                        }
                        Column(
                            modifier = Modifier.padding(16.dp),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = "${item.category.label.uppercase()} · ${item.year}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Text(
                                text = item.title,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = item.summary,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 2
                            )
                        }
                    }
                }
            }
        }
    }
}
