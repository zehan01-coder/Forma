package com.example.ui

import androidx.compose.runtime.Immutable
import androidx.lifecycle.ViewModel
import com.example.data.StudioRepository
import com.example.model.AeoFaqItem
import com.example.model.CaseStudy
import com.example.model.DriveMode
import com.example.model.SeoSchemaBlock
import com.example.model.ServicePillar
import com.example.model.TaycanTrim
import com.example.model.WebPreviewViewport
import com.example.model.WorkCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update

@Immutable
data class StudioUiState(
    val isDarkTheme: Boolean = true,
    val selectedPerspectiveIndex: Int = 0, // 0 = Exterior Aero, 1 = Cockpit HMI
    val selectedTrimIndex: Int = 0,
    val selectedDriveMode: DriveMode = DriveMode.SPORT,
    val selectedWorkCategory: WorkCategory = WorkCategory.ALL,
    val expandedServiceIndices: Set<String> = setOf("01"),
    val expandedFaqIndex: Int = 0,
    val webHubShowSchema: Boolean = false,
    val webViewport: WebPreviewViewport = WebPreviewViewport.MOBILE,
    val showInquirySheet: Boolean = false,
    val inquiryName: String = "",
    val inquiryEmail: String = "",
    val inquiryScope: String = "Flagship Website + SEO/AEO",
    val inquiryNote: String = "",
    val inquirySubmitted: Boolean = false,
    val inquiryError: String? = null,
    val newsletterEmail: String = "",
    val newsletterSubscribed: Boolean = false,
    val trims: List<TaycanTrim> = StudioRepository.taycanTrims,
    val allCaseStudies: List<CaseStudy> = StudioRepository.caseStudies,
    val services: List<ServicePillar> = StudioRepository.servicePillars,
    val faqs: List<AeoFaqItem> = StudioRepository.aeoFaqItems,
    val schemaBlocks: List<SeoSchemaBlock> = StudioRepository.seoSchemaBlocks
) {
    val activeTrim: TaycanTrim get() = trims.getOrElse(selectedTrimIndex) { trims.first() }

    val filteredCaseStudies: List<CaseStudy>
        get() = if (selectedWorkCategory == WorkCategory.ALL) {
            allCaseStudies
        } else {
            allCaseStudies.filter { it.category == selectedWorkCategory }
        }
}

class StudioViewModel : ViewModel() {

    private val _uiState = MutableStateFlow(StudioUiState())
    val uiState: StateFlow<StudioUiState> = _uiState.asStateFlow()

    fun toggleTheme() {
        _uiState.update { it.copy(isDarkTheme = !it.isDarkTheme) }
    }

    fun selectPerspective(index: Int) {
        _uiState.update { it.copy(selectedPerspectiveIndex = index.coerceIn(0, 1)) }
    }

    fun togglePerspective() {
        _uiState.update {
            it.copy(selectedPerspectiveIndex = if (it.selectedPerspectiveIndex == 0) 1 else 0)
        }
    }

    fun selectTrim(index: Int) {
        _uiState.update { it.copy(selectedTrimIndex = index.coerceIn(0, it.trims.lastIndex)) }
    }

    fun selectDriveMode(mode: DriveMode) {
        _uiState.update { it.copy(selectedDriveMode = mode) }
    }

    fun selectWorkCategory(category: WorkCategory) {
        _uiState.update { it.copy(selectedWorkCategory = category) }
    }

    fun toggleServiceExpanded(indexNumber: String) {
        _uiState.update { state ->
            val updated = state.expandedServiceIndices.toMutableSet()
            if (!updated.add(indexNumber)) {
                updated.remove(indexNumber)
            }
            state.copy(expandedServiceIndices = updated)
        }
    }

    fun selectFaqIndex(index: Int) {
        _uiState.update {
            it.copy(expandedFaqIndex = if (it.expandedFaqIndex == index) -1 else index)
        }
    }

    fun setWebHubMode(showSchema: Boolean) {
        _uiState.update { it.copy(webHubShowSchema = showSchema) }
    }

    fun setWebViewport(viewport: WebPreviewViewport) {
        _uiState.update { it.copy(webViewport = viewport) }
    }

    fun openInquirySheet(defaultScope: String? = null) {
        _uiState.update {
            it.copy(
                showInquirySheet = true,
                inquirySubmitted = false,
                inquiryError = null,
                inquiryScope = defaultScope ?: it.inquiryScope
            )
        }
    }

    fun closeInquirySheet() {
        _uiState.update { it.copy(showInquirySheet = false) }
    }

    fun updateInquiryName(value: String) {
        _uiState.update { it.copy(inquiryName = value, inquiryError = null) }
    }

    fun updateInquiryEmail(value: String) {
        _uiState.update { it.copy(inquiryEmail = value, inquiryError = null) }
    }

    fun updateInquiryScope(value: String) {
        _uiState.update { it.copy(inquiryScope = value) }
    }

    fun updateInquiryNote(value: String) {
        _uiState.update { it.copy(inquiryNote = value) }
    }

    fun submitInquiry() {
        val state = _uiState.value
        val name = state.inquiryName.trim()
        val email = state.inquiryEmail.trim()
        when {
            name.isEmpty() -> {
                _uiState.update { it.copy(inquiryError = "Please enter your name.") }
            }
            !email.contains("@") || !email.contains(".") -> {
                _uiState.update { it.copy(inquiryError = "Please enter a valid work email.") }
            }
            else -> {
                _uiState.update {
                    it.copy(
                        inquirySubmitted = true,
                        inquiryError = null
                    )
                }
            }
        }
    }

    fun updateNewsletterEmail(value: String) {
        _uiState.update { it.copy(newsletterEmail = value, newsletterSubscribed = false) }
    }

    fun submitNewsletter() {
        val email = _uiState.value.newsletterEmail.trim()
        if (email.contains("@") && email.contains(".")) {
            _uiState.update {
                it.copy(newsletterEmail = "", newsletterSubscribed = true)
            }
        }
    }

    fun getCaseStudyById(id: String): CaseStudy? {
        return _uiState.value.allCaseStudies.find { it.id == id }
    }
}
