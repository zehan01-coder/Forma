package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.outlined.DarkMode
import androidx.compose.material.icons.outlined.LightMode
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.StudioDestination
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.SignalEmerald
import com.example.ui.theme.SyneFontFamily

@Composable
fun ClayTopHeader(
    isDarkTheme: Boolean,
    showDesktopLinks: Boolean,
    currentDestination: StudioDestination,
    onNavigate: (StudioDestination) -> Unit,
    onToggleTheme: () -> Unit,
    onStartProject: () -> Unit,
    modifier: Modifier = Modifier
) {
    val pillBg by animateColorAsState(
        targetValue = MaterialTheme.colorScheme.surface.copy(alpha = 0.92f),
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "headerSurface"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .statusBarsPadding()
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .widthIn(max = 1180.dp)
                .fillMaxWidth(),
            shape = RoundedCornerShape(999.dp),
            color = pillBg,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            tonalElevation = 4.dp
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier
                        .clip(RoundedCornerShape(999.dp))
                        .clickable { onNavigate(StudioDestination.SHOWCASE) }
                        .padding(horizontal = 6.dp, vertical = 4.dp)
                        .testTag("header_brand_button")
                ) {
                    FormaGeometricMark(
                        color = MaterialTheme.colorScheme.onSurface,
                        accent = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "FORMA®",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = SyneFontFamily,
                            fontWeight = FontWeight.ExtraBold
                        ),
                        maxLines = 1
                    )
                }

                if (showDesktopLinks) {
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        val links = listOf(
                            StudioDestination.SHOWCASE to "Product",
                            StudioDestination.WORK to "Portfolio",
                            StudioDestination.SERVICES to "Services",
                            StudioDestination.WEB_SEO to "Web & SEO"
                        )
                        links.forEach { (dest, label) ->
                            val selected = dest == currentDestination
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = if (selected) MaterialTheme.colorScheme.surfaceVariant else Color.Transparent,
                                modifier = Modifier
                                    .minimumInteractiveComponentSize()
                                    .clip(RoundedCornerShape(999.dp))
                                    .clickable { onNavigate(dest) }
                                    .testTag("header_nav_${dest.route}")
                            ) {
                                Text(
                                    text = label,
                                    style = MaterialTheme.typography.labelLarge,
                                    color = if (selected) {
                                        MaterialTheme.colorScheme.onSurface
                                    } else {
                                        MaterialTheme.colorScheme.onSurfaceVariant
                                    },
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)
                                )
                            }
                        }
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    IconButton(
                        onClick = onToggleTheme,
                        modifier = Modifier
                            .size(44.dp)
                            .border(1.dp, MaterialTheme.colorScheme.outline, CircleShape)
                            .testTag("theme_toggle_button")
                    ) {
                        Icon(
                            imageVector = if (isDarkTheme) Icons.Outlined.LightMode else Icons.Outlined.DarkMode,
                            contentDescription = if (isDarkTheme) "Switch to Alabaster Light Theme" else "Switch to Obsidian Dark Theme",
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(18.dp)
                        )
                    }

                    Button(
                        onClick = onStartProject,
                        shape = RoundedCornerShape(999.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.onBackground,
                            contentColor = MaterialTheme.colorScheme.background
                        ),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 10.dp),
                        modifier = Modifier
                            .height(44.dp)
                            .testTag("header_start_project_button")
                    ) {
                        Text(
                            text = "Start Project",
                            style = MaterialTheme.typography.labelLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(15.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun FormaGeometricMark(
    color: Color,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier.size(22.dp)) {
        val w = size.width
        val h = size.height
        val path = Path().apply {
            moveTo(w * 0.2f, h * 0.15f)
            lineTo(w * 0.85f, h * 0.15f)
            lineTo(w * 0.85f, h * 0.34f)
            lineTo(w * 0.42f, h * 0.34f)
            lineTo(w * 0.42f, h * 0.48f)
            lineTo(w * 0.76f, h * 0.48f)
            lineTo(w * 0.76f, h * 0.66f)
            lineTo(w * 0.42f, h * 0.66f)
            lineTo(w * 0.42f, h * 0.88f)
            lineTo(w * 0.2f, h * 0.88f)
            close()
        }
        drawPath(path = path, color = color)

        val ribbon = Path().apply {
            moveTo(w * 0.54f, h * 0.50f)
            cubicTo(w * 0.72f, h * 0.50f, w * 0.86f, h * 0.40f, w * 0.92f, h * 0.26f)
        }
        drawPath(
            path = ribbon,
            color = accent,
            style = Stroke(width = w * 0.10f, cap = StrokeCap.Round)
        )
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun ClayEditorialFooter(
    newsletterEmail: String,
    newsletterSubscribed: Boolean,
    onNewsletterEmailChange: (String) -> Unit,
    onNewsletterSubmit: () -> Unit,
    onNavigate: (StudioDestination) -> Unit,
    onStartProject: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        color = MaterialTheme.colorScheme.surface,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 1180.dp)
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 32.dp)
        ) {
            // Clay-inspired Pre-Footer Conversion Banner
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(24.dp))
                    .border(1.dp, MaterialTheme.colorScheme.outline, RoundedCornerShape(24.dp))
                    .background(
                        Brush.linearGradient(
                            colors = listOf(
                                MaterialTheme.colorScheme.primary.copy(alpha = 0.16f),
                                MaterialTheme.colorScheme.surfaceVariant
                            )
                        )
                    )
                    .padding(24.dp)
            ) {
                Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text(
                        text = "05 / NEXT FLAGSHIP",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Build a product people feel.",
                        style = MaterialTheme.typography.displayMedium
                    )
                    Text(
                        text = "Partner with Forma® for interactive automotive HMIs, mobile-first Android apps, and SEO/AEO web architectures.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Button(
                        onClick = onStartProject,
                        shape = RoundedCornerShape(999.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = MaterialTheme.colorScheme.onBackground,
                            contentColor = MaterialTheme.colorScheme.background
                        ),
                        modifier = Modifier
                            .height(48.dp)
                            .testTag("footer_book_call_button")
                    ) {
                        Text("Book a Discovery Call", style = MaterialTheme.typography.labelLarge)
                        Spacer(modifier = Modifier.width(8.dp))
                        Icon(
                            imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Multi-Column Clay Footer Links
            FlowRow(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(28.dp),
                verticalArrangement = Arrangement.spacedBy(24.dp),
                maxItemsInEachRow = 4
            ) {
                Column(modifier = Modifier.widthIn(min = 140.dp, max = 240.dp)) {
                    Text(
                        text = "FORMA®",
                        style = MaterialTheme.typography.titleMedium.copy(
                            fontFamily = SyneFontFamily,
                            fontWeight = FontWeight.ExtraBold
                        )
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Digital product, automotive HMI & motion engineering studio. Zurich · San Francisco · Tokyo.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(7.dp)
                                    .clip(CircleShape)
                                    .background(SignalEmerald)
                            )
                            Text(
                                text = "Systems Operational · 99.98%",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                FooterLinkColumn(
                    title = "PRODUCT",
                    links = listOf(
                        "Taycan GT Stage" to { onNavigate(StudioDestination.SHOWCASE) },
                        "Motion System" to { onNavigate(StudioDestination.SERVICES) },
                        "Live Web Preview" to { onNavigate(StudioDestination.WEB_SEO) }
                    )
                )

                FooterLinkColumn(
                    title = "PORTFOLIO",
                    links = listOf(
                        "01 Taycan GT HMI" to { onNavigate(StudioDestination.WORK) },
                        "02 Krono M-Optics" to { onNavigate(StudioDestination.WORK) },
                        "03 Sona Monolith" to { onNavigate(StudioDestination.WORK) }
                    )
                )

                FooterLinkColumn(
                    title = "SEARCH & AEO",
                    links = listOf(
                        "JSON-LD Graph" to { onNavigate(StudioDestination.WEB_SEO) },
                        "AEO Direct FAQ" to { onNavigate(StudioDestination.SERVICES) },
                        "Start Commission" to onStartProject
                    )
                )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // Newsletter Dispatches Micro-Form
            Text(
                text = "STUDIO DISPATCHES",
                style = MaterialTheme.typography.labelMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = newsletterEmail,
                    onValueChange = onNewsletterEmailChange,
                    placeholder = { Text("you@company.com") },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Done
                    ),
                    keyboardActions = KeyboardActions(onDone = { onNewsletterSubmit() }),
                    shape = RoundedCornerShape(999.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = MaterialTheme.colorScheme.primary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    ),
                    modifier = Modifier
                        .weight(1f)
                        .testTag("footer_newsletter_input")
                )
                Button(
                    onClick = onNewsletterSubmit,
                    shape = CircleShape,
                    contentPadding = PaddingValues(0.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.onBackground,
                        contentColor = MaterialTheme.colorScheme.background
                    ),
                    modifier = Modifier
                        .size(52.dp)
                        .testTag("footer_newsletter_submit")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Rounded.ArrowForward,
                        contentDescription = "Subscribe to studio dispatches"
                    )
                }
            }

            AnimatedVisibility(visible = newsletterSubscribed) {
                Text(
                    text = "Subscribed to quarterly HMI & motion dispatches.",
                    style = MaterialTheme.typography.labelMedium,
                    color = SignalEmerald,
                    modifier = Modifier.padding(top = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "© 2026 Forma® Studio Inc.",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = "SEO · AEO · SCHEMA.ORG",
                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFamily),
                    color = MaterialTheme.colorScheme.primary
                )
            }
        }
    }
}

@Composable
private fun FooterLinkColumn(
    title: String,
    links: List<Pair<String, () -> Unit>>
) {
    Column(
        modifier = Modifier.widthIn(min = 130.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.padding(bottom = 4.dp)
        )
        links.forEach { (label, action) ->
            Box(
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = action)
                    .padding(vertical = 6.dp, horizontal = 2.dp),
                contentAlignment = Alignment.CenterStart
            ) {
                Text(
                    text = label,
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}
