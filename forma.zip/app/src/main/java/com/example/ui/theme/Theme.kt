package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.unit.dp

private val DarkColorScheme = darkColorScheme(
    primary = ElectricSapphire,
    onPrimary = TextOnDark,
    secondary = TextOnDark,
    onSecondary = ObsidianBg,
    tertiary = CarminePulse,
    background = ObsidianBg,
    onBackground = TextOnDark,
    surface = ObsidianSurface,
    onSurface = TextOnDark,
    surfaceVariant = ObsidianSurfaceElevated,
    onSurfaceVariant = MutedOnDark,
    outline = BorderOnDark
)

private val LightColorScheme = lightColorScheme(
    primary = ElectricSapphireDark,
    onPrimary = AlabasterSurface,
    secondary = TextOnLight,
    onSecondary = AlabasterBg,
    tertiary = CarminePulse,
    background = AlabasterBg,
    onBackground = TextOnLight,
    surface = AlabasterSurface,
    onSurface = TextOnLight,
    surfaceVariant = AlabasterSurfaceElevated,
    onSurfaceVariant = MutedOnLight,
    outline = BorderOnLight
)

val FormaShapes = Shapes(
    small = RoundedCornerShape(12.dp),
    medium = RoundedCornerShape(18.dp),
    large = RoundedCornerShape(24.dp),
    extraLarge = RoundedCornerShape(32.dp)
)

@Composable
fun FormaTheme(
    darkTheme: Boolean = true,
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = FormaTypography,
        shapes = FormaShapes,
        content = content
    )
}
