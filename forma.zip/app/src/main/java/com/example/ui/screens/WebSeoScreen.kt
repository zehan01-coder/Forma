package com.example.ui.screens

import android.annotation.SuppressLint
import android.content.Intent
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.rounded.CheckCircle
import androidx.compose.material.icons.rounded.Code
import androidx.compose.material.icons.rounded.Language
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import com.example.model.WebPreviewViewport
import com.example.ui.StudioUiState
import com.example.ui.theme.JetBrainsMonoFamily
import com.example.ui.theme.SignalEmerald

@Composable
fun WebSeoScreen(
    uiState: StudioUiState,
    onSetShowSchema: (Boolean) -> Unit,
    onSelectViewport: (WebPreviewViewport) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    var copiedMessage by remember { mutableStateOf<String?>(null) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .widthIn(max = 1180.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Mode Switcher: Live Website vs SEO/AEO/Schema Inspector
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = MaterialTheme.colorScheme.surface,
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(modifier = Modifier.padding(4.dp)) {
                        ModePill(
                            label = "Live Website",
                            icon = Icons.Rounded.Language,
                            selected = !uiState.webHubShowSchema,
                            onClick = { onSetShowSchema(false) },
                            tag = "web_hub_tab_preview"
                        )
                        ModePill(
                            label = "SEO · AEO · Schema",
                            icon = Icons.Rounded.Code,
                            selected = uiState.webHubShowSchema,
                            onClick = { onSetShowSchema(true) },
                            tag = "web_hub_tab_schema"
                        )
                    }
                }

                if (!uiState.webHubShowSchema) {
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        WebPreviewViewport.entries.forEach { vp ->
                            val selected = vp == uiState.webViewport
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface,
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                                modifier = Modifier
                                    .clip(RoundedCornerShape(999.dp))
                                    .clickable { onSelectViewport(vp) }
                                    .testTag("viewport_${vp.name.lowercase()}")
                            ) {
                                Text(
                                    text = vp.label,
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)
                                )
                            }
                        }
                    }
                }
            }

            copiedMessage?.let { msg ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = SignalEmerald.copy(alpha = 0.14f),
                    border = BorderStroke(1.dp, SignalEmerald.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.CheckCircle,
                            contentDescription = null,
                            tint = SignalEmerald,
                            modifier = Modifier.size(16.dp)
                        )
                        Text(msg, style = MaterialTheme.typography.labelLarge, color = SignalEmerald)
                    }
                }
            }

            AnimatedContent(
                targetState = uiState.webHubShowSchema,
                modifier = Modifier.weight(1f),
                label = "webHubContent"
            ) { showSchema ->
                if (!showSchema) {
                    LiveWebsitePreviewPane(viewport = uiState.webViewport)
                } else {
                    SeoAeoInspectorPane(
                        uiState = uiState,
                        onCopySnippet = { title, snippet ->
                            clipboard.setText(AnnotatedString(snippet))
                            copiedMessage = "Copied $title JSON-LD to clipboard."
                        },
                        onShareWebsiteHtml = {
                            val htmlSource = runCatching {
                                context.assets.open("website/index.html").bufferedReader().use { it.readText() }
                            }.getOrDefault("")
                            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Forma® Responsive Website + SEO/AEO/Schema HTML")
                                putExtra(Intent.EXTRA_TEXT, htmlSource)
                            }
                            context.startActivity(Intent.createChooser(sendIntent, "Export Website HTML"))
                        }
                    )
                }
            }
        }
    }
}

@Composable
private fun ModePill(
    label: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    selected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Surface(
        shape = RoundedCornerShape(999.dp),
        color = if (selected) MaterialTheme.colorScheme.onBackground else Color.Transparent,
        modifier = Modifier
            .clip(RoundedCornerShape(999.dp))
            .clickable(onClick = onClick)
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 12.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (selected) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.size(15.dp)
            )
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@SuppressLint("SetJavaScriptEnabled")
@Composable
private fun LiveWebsitePreviewPane(viewport: WebPreviewViewport) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(bottom = 8.dp),
        contentAlignment = Alignment.TopCenter
    ) {
        val frameModifier = if (viewport.maxWidthDp != null) {
            Modifier
                .widthIn(max = viewport.maxWidthDp.dp)
                .fillMaxSize()
        } else {
            Modifier.fillMaxSize()
        }

        Surface(
            modifier = frameModifier,
            shape = RoundedCornerShape(22.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
            color = Color(0xFF0B0B0D)
        ) {
            AndroidView(
                factory = { ctx ->
                    WebView(ctx).apply {
                        settings.javaScriptEnabled = true
                        settings.domStorageEnabled = true
                        settings.allowFileAccess = true
                        settings.cacheMode = WebSettings.LOAD_DEFAULT
                        webViewClient = WebViewClient()
                        loadUrl("file:///android_asset/website/index.html")
                    }
                },
                modifier = Modifier
                    .fillMaxSize()
                    .testTag("live_website_webview")
            )
        }
    }
}

@Composable
private fun SeoAeoInspectorPane(
    uiState: StudioUiState,
    onCopySnippet: (String, String) -> Unit,
    onShareWebsiteHtml: () -> Unit
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 24.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        text = "SEARCH & ANSWER ENGINE READINESS",
                        style = MaterialTheme.typography.labelMedium,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Text(
                        text = "Full SEO, AEO & JSON-LD @graph Embedded",
                        style = MaterialTheme.typography.titleLarge
                    )
                    Text(
                        text = "The bundled responsive website (assets/website/index.html) ships with Open Graph, Twitter Cards, canonical URLs, semantic FAQPage AEO blocks, and 4 Schema.org entities.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("SEO Meta", "AEO FAQPage", "JSON-LD @graph").forEach { badge ->
                            Surface(
                                shape = RoundedCornerShape(999.dp),
                                color = SignalEmerald.copy(alpha = 0.14f)
                            ) {
                                Text(
                                    text = "✓ $badge",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SignalEmerald,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(
                            onClick = onShareWebsiteHtml,
                            shape = RoundedCornerShape(999.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.onBackground,
                                contentColor = MaterialTheme.colorScheme.background
                            ),
                            modifier = Modifier
                                .height(46.dp)
                                .testTag("export_website_html_button")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.Share,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Export HTML Source", style = MaterialTheme.typography.labelLarge)
                        }

                        OutlinedButton(
                            onClick = {
                                val combined = uiState.schemaBlocks.joinToString(",\n") { it.snippet }
                                onCopySnippet("All JSON-LD Schemas", combined)
                            },
                            shape = RoundedCornerShape(999.dp),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                            modifier = Modifier
                                .height(46.dp)
                                .testTag("copy_all_schema_button")
                        ) {
                            Text("Copy Graph", color = MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
            }
        }

        items(uiState.schemaBlocks, key = { it.id }) { block ->
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = MaterialTheme.colorScheme.surface,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = block.schemaType,
                                style = MaterialTheme.typography.titleMedium
                            )
                            Text(
                                text = block.description,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(
                            onClick = { onCopySnippet(block.schemaType, block.snippet) },
                            modifier = Modifier.testTag("copy_schema_${block.id}")
                        ) {
                            Icon(
                                imageVector = Icons.Outlined.ContentCopy,
                                contentDescription = "Copy ${block.schemaType} JSON-LD"
                            )
                        }
                    }

                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(MaterialTheme.colorScheme.surfaceVariant)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = block.snippet,
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontFamily = JetBrainsMonoFamily
                            ),
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}
