package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val ObsidianBg = Color(0xFF0B0B0D)
val ObsidianSurface = Color(0xFF141519)
val ObsidianSurfaceElevated = Color(0xFF1C1E24)

val AlabasterBg = Color(0xFFF6F5F1)
val AlabasterSurface = Color(0xFFFFFFFF)
val AlabasterSurfaceElevated = Color(0xFFECEAE3)

val ElectricSapphire = Color(0xFF3B82F6)
val ElectricSapphireDark = Color(0xFF2563EB)
val CarminePulse = Color(0xFFEF4444)
val SignalEmerald = Color(0xFF22C55E)

val TextOnDark = Color(0xFFF6F5F1)
val MutedOnDark = Color(0xFF9CA0AB)
val BorderOnDark = Color(0x1FF6F5F1)

val TextOnLight = Color(0xFF0B0B0D)
val MutedOnLight = Color(0xFF5A5D66)
val BorderOnLight = Color(0x1F0B0B0D)
