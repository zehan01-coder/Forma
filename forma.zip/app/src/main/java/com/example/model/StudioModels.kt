package com.example.model

import androidx.annotation.DrawableRes
import androidx.compose.runtime.Immutable
import androidx.compose.ui.graphics.Color

enum class StudioDestination(val route: String) {
    SHOWCASE("showcase"),
    WORK("work"),
    SERVICES("services"),
    WEB_SEO("web_seo")
}

enum class WorkCategory(val label: String) {
    ALL("All"),
    AUTOMOTIVE("Automotive"),
    INDUSTRIAL("Industrial"),
    SYSTEMS("Systems")
}

enum class DriveMode(
    val label: String,
    val accel: String,
    val power: String,
    val drag: String,
    val refresh: String
) {
    RANGE("RANGE", "3.1s", "430 kW", "0.22 Cd", "90 Hz"),
    SPORT("SPORT", "2.6s", "560 kW", "0.22 Cd", "120 Hz"),
    TRACK("TRACK+", "2.2s", "760 kW", "0.21 Cd", "120 Hz")
}

enum class WebPreviewViewport(val label: String, val maxWidthDp: Int?) {
    MOBILE("Mobile", 392),
    TABLET("Tablet", 720),
    FULL("Full", null)
}

@Immutable
data class TaycanTrim(
    val name: String,
    val swatchColor: Color,
    val accentColor: Color,
    val materialCode: String
)

@Immutable
data class TelemetryMetric(
    val label: String,
    val value: String
)

@Immutable
data class CaseStudy(
    val id: String,
    val indexNumber: String,
    val title: String,
    val client: String,
    val year: String,
    val category: WorkCategory,
    val summary: String,
    val challenge: String,
    val solution: String,
    @DrawableRes val primaryImageRes: Int,
    @DrawableRes val secondaryImageRes: Int,
    val metrics: List<TelemetryMetric>,
    val deliverables: List<String>
)

@Immutable
data class ServicePillar(
    val indexNumber: String,
    val title: String,
    val timeline: String,
    val summary: String,
    val deliverables: List<String>
)

@Immutable
data class AeoFaqItem(
    val question: String,
    val answer: String
)

@Immutable
data class SeoSchemaBlock(
    val id: String,
    val schemaType: String,
    val description: String,
    val snippet: String
)
