package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.DesignServices
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.DesignServices
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Language
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationRail
import androidx.compose.material3.NavigationRailItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.example.model.StudioDestination
import com.example.ui.StudioUiState
import com.example.ui.StudioViewModel
import com.example.ui.components.ClayTopHeader
import com.example.ui.components.ProjectInquirySheet
import com.example.ui.screens.CaseStudyDetailScreen
import com.example.ui.screens.ServicesScreen
import com.example.ui.screens.ShowcaseScreen
import com.example.ui.screens.WebSeoScreen
import com.example.ui.screens.WorkScreen
import com.example.ui.theme.FormaTheme

private const val ROUTE_CASE_DETAIL = "case_detail/{caseId}"

private data class NavTabItem(
    val destination: StudioDestination,
    val label: String,
    val selectedIcon: ImageVector,
    val unselectedIcon: ImageVector
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val viewModel: StudioViewModel = viewModel()
            val uiState by viewModel.uiState.collectAsStateWithLifecycle()

            FormaTheme(darkTheme = uiState.isDarkTheme) {
                FormaStudioRoot(
                    uiState = uiState,
                    viewModel = viewModel
                )
            }
        }
    }
}

@Composable
fun FormaStudioRoot(
    uiState: StudioUiState,
    viewModel: StudioViewModel
) {
    val navController = rememberNavController()
    val backStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = backStackEntry?.destination?.route ?: StudioDestination.SHOWCASE.route
    val isDetailRoute = currentRoute.startsWith("case_detail")

    val currentDestination = StudioDestination.entries.find { it.route == currentRoute }
        ?: StudioDestination.SHOWCASE

    val navItems = listOf(
        NavTabItem(
            destination = StudioDestination.SHOWCASE,
            label = "Showcase",
            selectedIcon = Icons.Filled.AutoAwesome,
            unselectedIcon = Icons.Outlined.AutoAwesome
        ),
        NavTabItem(
            destination = StudioDestination.WORK,
            label = "Work",
            selectedIcon = Icons.Filled.GridView,
            unselectedIcon = Icons.Outlined.GridView
        ),
        NavTabItem(
            destination = StudioDestination.SERVICES,
            label = "Services",
            selectedIcon = Icons.Filled.DesignServices,
            unselectedIcon = Icons.Outlined.DesignServices
        ),
        NavTabItem(
            destination = StudioDestination.WEB_SEO,
            label = "Web & SEO",
            selectedIcon = Icons.Filled.Language,
            unselectedIcon = Icons.Outlined.Language
        )
    )

    fun navigateToTab(destination: StudioDestination) {
        navController.navigate(destination.route) {
            popUpTo(navController.graph.findStartDestination().id) {
                saveState = true
            }
            launchSingleTop = true
            restoreState = true
        }
    }

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isExpanded = maxWidth >= 840.dp
        val isMediumOrExpanded = maxWidth >= 600.dp

        Scaffold(
            modifier = Modifier.fillMaxSize(),
            containerColor = MaterialTheme.colorScheme.background,
            contentWindowInsets = WindowInsets(0, 0, 0, 0),
            topBar = {
                if (!isDetailRoute) {
                    ClayTopHeader(
                        isDarkTheme = uiState.isDarkTheme,
                        showDesktopLinks = isExpanded,
                        currentDestination = currentDestination,
                        onNavigate = ::navigateToTab,
                        onToggleTheme = viewModel::toggleTheme,
                        onStartProject = { viewModel.openInquirySheet() }
                    )
                }
            },
            bottomBar = {
                if (!isDetailRoute && !isMediumOrExpanded) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 4.dp
                    ) {
                        navItems.forEach { item ->
                            val selected = currentDestination == item.destination
                            NavigationBarItem(
                                selected = selected,
                                onClick = { navigateToTab(item.destination) },
                                icon = {
                                    Icon(
                                        imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                        contentDescription = item.label
                                    )
                                },
                                label = {
                                    Text(
                                        text = item.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1
                                    )
                                },
                                modifier = Modifier.testTag("bottom_nav_${item.destination.route}")
                            )
                        }
                    }
                }
            }
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (!isDetailRoute && isMediumOrExpanded) {
                    NavigationRail(
                        containerColor = MaterialTheme.colorScheme.surface,
                        modifier = Modifier.fillMaxHeight()
                    ) {
                        Column(modifier = Modifier.padding(top = 12.dp)) {
                            navItems.forEach { item ->
                                val selected = currentDestination == item.destination
                                NavigationRailItem(
                                    selected = selected,
                                    onClick = { navigateToTab(item.destination) },
                                    icon = {
                                        Icon(
                                            imageVector = if (selected) item.selectedIcon else item.unselectedIcon,
                                            contentDescription = item.label
                                        )
                                    },
                                    label = { Text(item.label, style = MaterialTheme.typography.labelSmall) },
                                    modifier = Modifier.testTag("rail_nav_${item.destination.route}")
                                )
                            }
                        }
                    }
                }

                Box(modifier = Modifier.weight(1f)) {
                    FormaNavHost(
                        navController = navController,
                        uiState = uiState,
                        viewModel = viewModel,
                        onNavigateTab = ::navigateToTab
                    )
                }
            }
        }
    }

    if (uiState.showInquirySheet) {
        ProjectInquirySheet(
            uiState = uiState,
            onDismiss = viewModel::closeInquirySheet,
            onNameChange = viewModel::updateInquiryName,
            onEmailChange = viewModel::updateInquiryEmail,
            onScopeChange = viewModel::updateInquiryScope,
            onNoteChange = viewModel::updateInquiryNote,
            onSubmit = viewModel::submitInquiry
        )
    }
}

@Composable
private fun FormaNavHost(
    navController: NavHostController,
    uiState: StudioUiState,
    viewModel: StudioViewModel,
    onNavigateTab: (StudioDestination) -> Unit
) {
    NavHost(
        navController = navController,
        startDestination = StudioDestination.SHOWCASE.route,
        enterTransition = { fadeIn(spring(stiffness = Spring.StiffnessMediumLow)) },
        exitTransition = { fadeOut(spring(stiffness = Spring.StiffnessMediumLow)) }
    ) {
        composable(StudioDestination.SHOWCASE.route) {
            ShowcaseScreen(
                uiState = uiState,
                onSelectPerspective = viewModel::selectPerspective,
                onTogglePerspective = viewModel::togglePerspective,
                onSelectTrim = viewModel::selectTrim,
                onSelectDriveMode = viewModel::selectDriveMode,
                onOpenCaseStudy = { study ->
                    navController.navigate("case_detail/${study.id}")
                },
                onOpenWebPreview = {
                    viewModel.setWebHubMode(false)
                    onNavigateTab(StudioDestination.WEB_SEO)
                },
                onNavigate = onNavigateTab,
                onStartProject = { viewModel.openInquirySheet() },
                onNewsletterEmailChange = viewModel::updateNewsletterEmail,
                onNewsletterSubmit = viewModel::submitNewsletter
            )
        }

        composable(StudioDestination.WORK.route) {
            WorkScreen(
                uiState = uiState,
                onSelectCategory = viewModel::selectWorkCategory,
                onOpenCaseStudy = { study ->
                    navController.navigate("case_detail/${study.id}")
                },
                onNavigate = onNavigateTab,
                onStartProject = { viewModel.openInquirySheet() },
                onNewsletterEmailChange = viewModel::updateNewsletterEmail,
                onNewsletterSubmit = viewModel::submitNewsletter
            )
        }

        composable(StudioDestination.SERVICES.route) {
            ServicesScreen(
                uiState = uiState,
                onToggleService = viewModel::toggleServiceExpanded,
                onSelectFaq = viewModel::selectFaqIndex,
                onNavigate = onNavigateTab,
                onStartProject = { viewModel.openInquirySheet() },
                onNewsletterEmailChange = viewModel::updateNewsletterEmail,
                onNewsletterSubmit = viewModel::submitNewsletter
            )
        }

        composable(StudioDestination.WEB_SEO.route) {
            WebSeoScreen(
                uiState = uiState,
                onSetShowSchema = viewModel::setWebHubMode,
                onSelectViewport = viewModel::setWebViewport
            )
        }

        composable(
            route = ROUTE_CASE_DETAIL,
            arguments = listOf(navArgument("caseId") { type = NavType.StringType })
        ) { entry ->
            val caseId = entry.arguments?.getString("caseId").orEmpty()
            val caseStudy = viewModel.getCaseStudyById(caseId) ?: uiState.allCaseStudies.first()
            CaseStudyDetailScreen(
                caseStudy = caseStudy,
                onBack = { navController.popBackStack() },
                onRequestSimilar = { title ->
                    viewModel.openInquirySheet(defaultScope = "Similar to: $title")
                }
            )
        }
    }
}
