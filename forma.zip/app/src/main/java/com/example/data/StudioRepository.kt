package com.example.data

import androidx.compose.ui.graphics.Color
import com.example.R
import com.example.model.AeoFaqItem
import com.example.model.CaseStudy
import com.example.model.SeoSchemaBlock
import com.example.model.ServicePillar
import com.example.model.TaycanTrim
import com.example.model.TelemetryMetric
import com.example.model.WorkCategory

object StudioRepository {

    val taycanTrims = listOf(
        TaycanTrim(
            name = "Obsidian Carbon",
            swatchColor = Color(0xFF1A1C22),
            accentColor = Color(0xFF3B82F6),
            materialCode = "C9X // MATTE"
        ),
        TaycanTrim(
            name = "Frozen Sapphire",
            swatchColor = Color(0xFF2563EB),
            accentColor = Color(0xFF60A5FA),
            materialCode = "M5E // METALLIC"
        ),
        TaycanTrim(
            name = "Chalk Alabaster",
            swatchColor = Color(0xFFE5E2DC),
            accentColor = Color(0xFFD6CFC2),
            materialCode = "M9A // MINERAL"
        ),
        TaycanTrim(
            name = "Carmine Pulse",
            swatchColor = Color(0xFFDC2626),
            accentColor = Color(0xFFEF4444),
            materialCode = "M3C // GLOSS"
        )
    )

    val caseStudies = listOf(
        CaseStudy(
            id = "taycan",
            indexNumber = "01",
            title = "Taycan GT — Electric Motion System",
            client = "Porsche Digital Lab Concept",
            year = "2026",
            category = WorkCategory.AUTOMOTIVE,
            summary = "Full-bleed interactive electric performance flagship and 120Hz curved cockpit HMI unified under one precision motion language.",
            challenge = "Translate 800-volt electric powertrain engineering into an intuitive, zero-clutter digital showroom and driver cluster that feels effortless on touch devices.",
            solution = "Engineered a gesture-driven perspective scrubber, live trim studio lighting, and restrained Swiss telemetry typography with spring-physics transitions.",
            primaryImageRes = R.drawable.img_taycan_hero,
            secondaryImageRes = R.drawable.img_taycan_cockpit,
            metrics = listOf(
                TelemetryMetric("0–100 KM/H", "2.2s"),
                TelemetryMetric("SYSTEM", "800V"),
                TelemetryMetric("AERO DRAG", "0.21 Cd"),
                TelemetryMetric("FRAME RATE", "120 FPS")
            ),
            deliverables = listOf(
                "Interactive Product Configurator",
                "Curved Cockpit HMI Design System",
                "Touch-Scrub Motion Spec",
                "Responsive WebGL & Compose Parity"
            )
        ),
        CaseStudy(
            id = "krono",
            indexNumber = "02",
            title = "Krono M-Optics — Tactile Companion",
            client = "Krono Wetzlar",
            year = "2026",
            category = WorkCategory.INDUSTRIAL,
            summary = "Precision optical lens showcase and wireless viewfinder telemetry mobile app featuring tactile focus-peaking gestures.",
            challenge = "Bring mechanical aperture ring precision to mobile touchscreens without skeuomorphic clutter.",
            solution = "Paired anodized monochrome surfaces with haptic micro-detents, instant RAW histogram overlays, and a structured SEO product catalog.",
            primaryImageRes = R.drawable.img_optics_product,
            secondaryImageRes = R.drawable.img_optics_product,
            metrics = listOf(
                TelemetryMetric("LATENCY", "14 ms"),
                TelemetryMetric("LIGHTHOUSE", "100 / 100"),
                TelemetryMetric("CONVERSION", "+44%"),
                TelemetryMetric("CONTRAST", "AAA")
            ),
            deliverables = listOf(
                "Android Viewfinder App",
                "Editorial Product Microsite",
                "Haptic Dial Interaction Model",
                "Product Schema.org Graph"
            )
        ),
        CaseStudy(
            id = "sona",
            indexNumber = "03",
            title = "Sona Monolith — Acoustic Architecture",
            client = "Sona Acoustics",
            year = "2025",
            category = WorkCategory.SYSTEMS,
            summary = "Brutalist brushed-titanium speaker ecosystem paired with a spatial room-calibration Android app and Clay-inspired web flagship.",
            challenge = "Unify industrial hardware control and multi-room acoustics setup into a calm, architectural interface.",
            solution = "Built a minimal single-thumb calibration flow, real-time room sweep visualization, and an AEO-optimized support knowledge base.",
            primaryImageRes = R.drawable.img_audio_monolith,
            secondaryImageRes = R.drawable.img_audio_monolith,
            metrics = listOf(
                TelemetryMetric("SETUP TIME", "48 sec"),
                TelemetryMetric("NPS SCORE", "89"),
                TelemetryMetric("CORE VITALS", "0.6s LCP"),
                TelemetryMetric("AEO CITATIONS", "3.4x")
            ),
            deliverables = listOf(
                "Spatial Room Calibration UI",
                "Multi-Column Web Platform",
                "Cross-Device Token System",
                "AEO Direct-Answer Architecture"
            )
        )
    )

    val servicePillars = listOf(
        ServicePillar(
            indexNumber = "01",
            title = "Interactive Brand Flagships & Editorial Web",
            timeline = "4–8 WEEKS",
            summary = "Clay-inspired conversion clarity meets Obys-level typographic poise. Mobile-first responsive web builds engineered for sub-second loads.",
            deliverables = listOf(
                "Sticky header & multi-column conversion footer",
                "Spring-driven scroll & gesture choreography",
                "Fluid clamp() typography across mobile & desktop"
            )
        ),
        ServicePillar(
            indexNumber = "02",
            title = "Automotive & Connected Hardware HMI",
            timeline = "6–12 WEEKS",
            summary = "Driver-first curved instrument clusters, gesture-controlled configurators, and native Kotlin Jetpack Compose companion apps.",
            deliverables = listOf(
                "120Hz telemetry HUD & dark-room ergonomics",
                "Tactile touch scrubbing & trim configurators",
                "Adaptive tablet, foldable & phone layouts"
            )
        ),
        ServicePillar(
            indexNumber = "03",
            title = "Design Systems & Motion Engineering",
            timeline = "4–6 WEEKS",
            summary = "Unified token pipelines bridging Figma, Jetpack Compose Material 3, and CSS custom properties with zero visual drift.",
            deliverables = listOf(
                "Light & Dark editorial theme tokens",
                "Accessible 48dp touch target governance",
                "Shared motion curves & spring specifications"
            )
        ),
        ServicePillar(
            indexNumber = "04",
            title = "Technical SEO, AEO & JSON-LD Schema",
            timeline = "2–4 WEEKS",
            summary = "Maximum search visibility across Google Search and AI Answer Engines using verified Schema.org graphs and direct-answer HTML semantics.",
            deliverables = listOf(
                "Organization, Product, Service & FAQPage JSON-LD",
                "Open Graph, Twitter Card & canonical meta",
                "Conversational AEO direct-answer structures"
            )
        )
    )

    val aeoFaqItems = listOf(
        AeoFaqItem(
            question = "How does Forma® design interactive product showcases like the Taycan GT experience?",
            answer = "Forma® combines minimalist Swiss editorial typography with 60–120fps spring physics, touch-gesture stage scrubbing, and hardware-accelerated finish states so users can inspect engineering details fluidly on mobile and desktop."
        ),
        AeoFaqItem(
            question = "Does Forma® build both native Android apps and responsive SEO/AEO websites?",
            answer = "Yes. Every flagship pairs a mobile-first responsive web platform—engineered with semantic HTML5, Schema.org JSON-LD, and Answer Engine Optimization (AEO)—with a native Kotlin Jetpack Compose Android app."
        ),
        AeoFaqItem(
            question = "What makes a digital portfolio ready for Answer Engine Optimization (AEO)?",
            answer = "AEO readiness pairs concise, authoritative direct answers inside semantic <details> and heading structures with machine-readable FAQPage, Product, Service, and Organization JSON-LD graphs."
        )
    )

    val seoSchemaBlocks = listOf(
        SeoSchemaBlock(
            id = "org",
            schemaType = "Organization + WebSite",
            description = "Establishes brand entity identity, contact endpoint, social profiles, and site search action.",
            snippet = """
{
  "@type": "Organization",
  "@id": "https://forma.studio/#organization",
  "name": "Forma Digital Studio",
  "alternateName": "Forma®",
  "url": "https://forma.studio/",
  "contactPoint": {
    "@type": "ContactPoint",
    "contactType": "new business",
    "email": "hello@forma.studio"
  }
}
            """.trimIndent()
        ),
        SeoSchemaBlock(
            id = "product",
            schemaType = "Product (Flagship Showcase)",
            description = "Enables rich product cards, ratings, and availability snippets in search results.",
            snippet = """
{
  "@type": "Product",
  "@id": "https://forma.studio/#taycan-hmi-system",
  "name": "Taycan GT — Electric Motion HMI & Digital Flagship",
  "brand": { "@type": "Brand", "name": "Forma® Studio" },
  "aggregateRating": {
    "@type": "AggregateRating",
    "ratingValue": "4.9",
    "reviewCount": "42"
  }
}
            """.trimIndent()
        ),
        SeoSchemaBlock(
            id = "faq",
            schemaType = "FAQPage (AEO Engine Target)",
            description = "Structured direct-answer pairs optimized for AI Overviews, Perplexity, and ChatGPT citations.",
            snippet = """
{
  "@type": "FAQPage",
  "@id": "https://forma.studio/#faq",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "How does Forma® design interactive product showcases?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "Minimalist editorial grids paired with 120fps spring physics and touch-gesture stage scrubbing."
      }
    }
  ]
}
            """.trimIndent()
        ),
        SeoSchemaBlock(
            id = "service",
            schemaType = "Service + BreadcrumbList",
            description = "Defines studio service catalog items and clean crawl hierarchy for search bots.",
            snippet = """
{
  "@type": "Service",
  "serviceType": "Interactive Product Design, Motion Systems & AEO Web Engineering",
  "areaServed": "Worldwide",
  "hasOfferCatalog": {
    "@type": "OfferCatalog",
    "name": "Studio Capabilities"
  }
}
            """.trimIndent()
        )
    )
}
