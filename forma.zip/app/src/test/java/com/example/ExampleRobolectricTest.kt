package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app name from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Forma", appName)
    }

    @Test
    fun `bundled website includes seo aeo and schema markup`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val html = context.assets.open("website/index.html").bufferedReader().use { it.readText() }
        assertTrue(html.contains("application/ld+json"))
        assertTrue(html.contains("FAQPage"))
        assertTrue(html.contains("Organization"))
        assertTrue(html.contains("Taycan GT"))
    }
}
