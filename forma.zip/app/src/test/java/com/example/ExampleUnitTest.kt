package com.example

import com.example.data.StudioRepository
import com.example.model.DriveMode
import com.example.model.WorkCategory
import com.example.ui.StudioViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `studio repository contains case studies and schema blocks`() {
        assertEquals(3, StudioRepository.caseStudies.size)
        assertEquals(4, StudioRepository.seoSchemaBlocks.size)
        assertTrue(StudioRepository.seoSchemaBlocks.any { it.schemaType.contains("FAQPage") })
    }

    @Test
    fun `view model handles perspective trim drive mode and portfolio filtering`() {
        val vm = StudioViewModel()
        assertEquals(0, vm.uiState.value.selectedPerspectiveIndex)

        vm.togglePerspective()
        assertEquals(1, vm.uiState.value.selectedPerspectiveIndex)

        vm.selectTrim(2)
        assertEquals("Chalk Alabaster", vm.uiState.value.activeTrim.name)

        vm.selectDriveMode(DriveMode.TRACK)
        assertEquals("2.2s", vm.uiState.value.selectedDriveMode.accel)

        vm.selectWorkCategory(WorkCategory.AUTOMOTIVE)
        assertEquals(1, vm.uiState.value.filteredCaseStudies.size)
    }

    @Test
    fun `inquiry validation rejects invalid email and accepts valid brief`() {
        val vm = StudioViewModel()
        vm.updateInquiryName("Alex")
        vm.updateInquiryEmail("invalid-email")
        vm.submitInquiry()
        assertFalse(vm.uiState.value.inquirySubmitted)

        vm.updateInquiryEmail("alex@forma.studio")
        vm.submitInquiry()
        assertTrue(vm.uiState.value.inquirySubmitted)
    }
}
